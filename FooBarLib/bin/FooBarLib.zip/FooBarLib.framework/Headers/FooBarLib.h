//
//  FooBarLib.h
//  FooBarLib
//
//  Created by Shridhar Damale on 30/03/17.
//  Copyright © 2017 Shridhar Damale. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for FooBarLib.
FOUNDATION_EXPORT double FooBarLibVersionNumber;

//! Project version string for FooBarLib.
FOUNDATION_EXPORT const unsigned char FooBarLibVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FooBarLib/PublicHeader.h>


