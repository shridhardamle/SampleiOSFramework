//
//  FooBarClass.h
//  FooBarLib
//
//  Created by Shridhar Damale on 30/03/17.
//  Copyright © 2017 Shridhar Damale. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FooBarClass : NSObject
-(bool) fooBarFunc;
@end
